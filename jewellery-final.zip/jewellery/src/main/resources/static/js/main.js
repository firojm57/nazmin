const container = document.querySelector(".container"),
    pwShowHide = document.querySelectorAll(".showHidePW"),
    pwFields = document.querySelectorAll(".password"),
    signup = document.querySelector(".signup-link"),
    login = document.querySelector(".login-link");

// js code to show/hide password and change icon
if(pwShowHide) {
    pwShowHide.forEach(eyeIcon => {
        eyeIcon.addEventListener("click", () => {
            pwFields.forEach(pwField => {
                if (pwField.type == "password") {
                    pwField.type = "text";

                    pwShowHide.forEach(icon => {
                        icon.classList.replace("uil-eye-slash", "uil-eye")
                    })
                } else {
                    pwField.type = "password";

                    pwShowHide.forEach(icon => {
                        icon.classList.replace("uil-eye", "uil-eye-slash")
                    })
                }
            })
        })
    })
}
// js code to appear signup and login
if(signup) {
    signup.addEventListener("click", () => {
        container.classList.add("active");
    });
}

if(login) {
    login.addEventListener("click", () => {
        container.classList.remove("active");
    });
}

let outOfStockErrorDiv = document.getElementById("outOfStockErrorDiv");

setTimeout(() => {
    if(outOfStockErrorDiv) {
        outOfStockErrorDiv.style.display = "none";
    }
}, 3000);

function onSubmitSignup() {
    console.info("got into signup")
    const pword = document.getElementById("pword"),
        confirmPword = document.getElementById("confirmPword"),
        signupError = document.getElementById("signupError");
    console.info(pword.value);
    if(pword.value != confirmPword.value) {
        signupError.classList.add("show");
        signupError.classList.remove("hidden");
        return false;
    } else {
        signupError.classList.add("hidden");
        signupError.classList.remove("show");
        return true;
    }
}

function removeTheParent(closeIcon) {
    let ele = closeIcon.parentNode;
    ele.remove();
    let dropDown = document.getElementById("itemTypeInBillSelect");
    if(dropDown) {
        dropDown.selectedIndex = 1;
    }
}

function onJewellerySelect() {
    var value = document.getElementById("itemTypeInBillSelect").value;
    if(value) {
        let splitted = value.split("|");
        let itemAdded = document.getElementById("item-id-" + splitted[0]);
        if(!itemAdded) {
            var domToAddChildren = document.getElementById("gridParentIdAddChildren");
            var newFlexNode = document.createElement("div");
            newFlexNode.id = "item-id-" + splitted[0];
            newFlexNode.classList.add("input-container");
            newFlexNode.innerHTML = '<i class="uil uil-times close-input-container" onclick="removeTheParent(this)"></i>' +
                                '<div class="flex">' +
                                '<input type="hidden" name="itemIds" value="'+splitted[0]+'">' +
                                    '<div class="input-field">' +
                                        '<input type="text" name="sellPrices" placeholder="Selling price" required>' +
                                    '</div>' +
                                    '<div class="input-field">' +
                                        '<input type="text" name="sellGSTs" placeholder="Selling GST" required>' +
                                    '</div>' +
                                '</div>' +
                                '<div class="input-field">' +
                                    '<input type="text" value="Item Name: '+splitted[1]+'" disabled>' +
                                '</div>' +
                                '<div class="input-field">' +
                                    '<input type="text" name="makingCharges" placeholder="Enter making charges" required>' +
                                '</div>';
            domToAddChildren.appendChild(newFlexNode);
        }
    }
    console.info(value);
}

function onClickDeleteUser(username) {
    let modal = document.getElementById("deleteConfirmModal");
    let usernameInput = document.getElementsByName("username")[0];
    usernameInput.value = username;
    console.info(usernameInput);
    modal.style.display = "block";
}

function onCloseModalClick() {
    let modal = document.getElementById("deleteConfirmModal");
    modal.style.display = "none";
}

window.onclick = function(event) {
    let modal = document.getElementById("deleteConfirmModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function onPrintBill() {
    let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=150');
    let title = "Print bill";
    let style = `<style>
    .invoice-container {
        width: 80%;
        margin-left: auto;
        margin-right: auto;
        background-color: white;
        border-radius: 8px;
    }
    .flex {
        display: flex;
    }
    .space-between-p36 {
        justify-content: space-between;
        padding: 36px;
    }
    .left-align-p36 {
        justify-content: end;
        padding: 36px;
    }
    .details-header {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
    }
    table {
        border-spacing: 1;
        border-collapse: collapse;
        background: white;
        border-radius: 6px;
        overflow: hidden;
        max-width: 950px;
        width: 100%;
        margin: 0 auto;
        position: relative;
    }
    
    table * {
        position: relative;
    }
    
    table td,
    table th {
        padding-left: 16px;
        padding-right: 16px;
    }
    
    table thead tr {
        height: 60px;
        background: #FFED86;
        font-size: 15px;
    }
    
    table tbody tr {
        height: 48px;
        border-bottom: 1px solid #E3F1D5;
    }
    
    table tbody tr:last-child {
        border: 0;
    }
    
    table td,
    table th {
        text-align: left;
    }
    
    table td.l,
    table th.l {
        text-align: right;
    }
    
    table td.c,
    table th.c {
        text-align: center;
    }
    
    table td.r,
    table th.r {
        text-align: center;
    }
    .text-m {
        font-size: 16px;
    }
    .bold {
        font-weight: 800;
    }
    </style>`

    mywindow.document.write(`<html><head>${style}<title>${title}</title>`);
    mywindow.document.write('</head><body>');
    mywindow.document.write(document.getElementById("billDivToPrint").innerHTML);
    mywindow.document.write('</body></html>');

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}