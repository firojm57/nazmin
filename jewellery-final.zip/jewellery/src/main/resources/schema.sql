create table if not exists shop_details (
	shop_id bigserial primary key,
	shop_name varchar,
	shop_logo text,
	shop_address varchar
);

create table if not exists users (
	username varchar primary key,
	password varchar,
	enabled int,
	first_name varchar,
	last_name varchar,
	email varchar,
	mobile_no bigint,
	address varchar,
	created_at timestamp,
	shop_id bigint references shop_details(shop_id)
);

create table if not exists authorities (
	username varchar references users(username),
	authority varchar
);

create table if not exists jewellery_details (
	item_id bigserial primary key,
	item_name varchar,
	item_type varchar,
	stock bigint,
	carat int,
	price decimal,
	GST decimal,
	purchase_date timestamp,
	shop_id bigint references shop_details(shop_id)
);

create table if not exists bill_details (
	item_id bigint references jewellery_details(item_id),
	bill_id bigint,
	cust_name varchar,
	sell_price decimal,
	sell_GST decimal,
	making_charges decimal,
	cust_mobile bigint,
	sell_date date,
	shop_id bigint references shop_details(shop_id),
	primary key (bill_id, item_id)
);
