package org.greenboard.jewellery.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class SessionDto {
    private String logoImagePath;
    private String userRole;
    private long shopId;
}
