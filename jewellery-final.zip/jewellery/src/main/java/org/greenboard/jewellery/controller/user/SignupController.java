package org.greenboard.jewellery.controller.user;

import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.signup.SignupDao;
import org.greenboard.jewellery.dto.SignupDto;
import org.greenboard.jewellery.model.SignupModel;
import org.greenboard.jewellery.util.FileUploadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.ServletContext;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class SignupController extends BaseController {
    @Autowired
    private SignupDao signupDao;

    @Autowired
    private BCryptPasswordEncoder encoder;

    @Autowired
    private ServletContext context;

    @PostMapping(
            value = "/doSignup",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public String doSignup(Model model, SignupModel signupModel) throws IOException {
        String logoFileName = StringUtils.cleanPath(signupModel.getImgLogo().getOriginalFilename());
        String pattern = new SimpleDateFormat("ddMMyy-hhmmss.SSS").format(new Date());
        logoFileName = pattern + logoFileName;

        String logoUploadPath = context.getRealPath(FileUploadUtils.STATIC_IMAGES_LOGO);
        logger.info("Real path: " + logoUploadPath);

        String uploadFilePath = FileUploadUtils.saveFile(Paths.get(logoUploadPath), logoFileName, signupModel.getImgLogo());
        logger.info("Final uploaded file: " + uploadFilePath);

        String encodedPass = encoder.encode(signupModel.getPassword());

        SignupDto signupDto = new SignupDto(signupModel.getUsername(), signupModel.getEmailId(), encodedPass,
                signupModel.getFirstName(), signupModel.getLastName(), signupModel.getMobileNo(), signupModel.getUserAddr(),
                signupModel.getShopName(), signupModel.getShopAddr(), uploadFilePath);
        signupDao.saveSignupUser(signupDto);
        logger.info("Data saved");

        model.addAttribute("signupMessage", "Signup successful, please login to continue");
        return "signup";
    }

    @GetMapping("/errorLogin")
    public String postLoginActivity(Model model) {
        logger.error("Error while login");
        model.addAttribute("loginError", "Invalid credentials!!");
        return "signup";
    }
}
