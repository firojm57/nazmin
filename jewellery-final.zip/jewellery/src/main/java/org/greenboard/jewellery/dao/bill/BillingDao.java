package org.greenboard.jewellery.dao.bill;

import org.greenboard.jewellery.OutOfStockException;
import org.greenboard.jewellery.dao.BaseDao;
import org.greenboard.jewellery.model.BillJewelleriesModel;
import org.greenboard.jewellery.model.BillingAllRespModel;
import org.greenboard.jewellery.model.BillingModel;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

@Repository
public class BillingDao extends BaseDao {

    public List<BillingAllRespModel> getAllBills(long shopId) {
        String allBillsQuery = "select distinct on(bill_id) bill_id, cust_name, cust_mobile, sell_date from bill_details where shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        return namedTemplate.query(allBillsQuery, map, (rs, rowNum) -> new BillingAllRespModel(
                rs.getLong("bill_id"), rs.getString("cust_name"),
                rs.getLong("cust_mobile"),
                Optional.ofNullable(rs.getDate("sell_date")).map(Date::toString).orElse("")
        ));
    }

    public BillingAllRespModel getBillCustomerDetail(long id, long shopId) {
        String allBillsQuery = "select distinct on(bill_id) bill_id, cust_name, cust_mobile, sell_date from bill_details\n" +
                "where shop_id = :shopId and bill_id = :billId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        map.addValue("billId", id);
        return namedTemplate.query(allBillsQuery, map, (rs, rowNum) -> new BillingAllRespModel(
                rs.getLong("bill_id"), rs.getString("cust_name"),
                rs.getLong("cust_mobile"),
                Optional.ofNullable(rs.getDate("sell_date")).map(Date::toString).orElse("")
        )).get(0);
    }

    public void saveBilling(BillingModel model, long shopId) throws OutOfStockException {
        // Handle stock
        String stockQuery = "select count(1) as stock from jewellery_details where stock = 0 and item_id in (:itemIds) and shop_id = :shopId";
        MapSqlParameterSource stockParam = new MapSqlParameterSource("itemIds", model.getItemIds());
        stockParam.addValue("shopId", shopId);
        List<Integer> stock = namedTemplate.query(stockQuery, stockParam, (rs, rowNum) -> rs.getInt("stock"));
        if (stock.isEmpty() || stock.get(0) == 0) {
            throw new OutOfStockException("Stock zero");
        }

        // Save bill
        String getBillIdQuery = "select max(bill_id) as bill_id from bill_details where shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        List<Long> billIds = namedTemplate.query(getBillIdQuery, map, (rs, rowNum) -> rs.getLong("bill_id"));
        long billId = Optional.ofNullable(billIds.get(0)).orElse(0L) + 1;

        for (int i = 0; i < model.getItemIds().size(); i++) {
            String insertQuery = "insert into bill_details(item_id, bill_id, cust_name, sell_price, sell_gst, making_charges, cust_mobile, sell_date, shop_id)\n" +
                    "values(:itemId, :billId, :custName, :sellPrice, :sellGst, :makingCharges, :custMobile, now(), :shopId)";
            MapSqlParameterSource insertMap = new MapSqlParameterSource();
            insertMap.addValue("itemId", model.getItemIds().get(i));
            insertMap.addValue("billId", billId);
            insertMap.addValue("custName", model.getCustName());
            insertMap.addValue("custMobile", model.getCustMobile());
            insertMap.addValue("sellPrice", model.getSellPrices().get(i));
            insertMap.addValue("sellGst", model.getSellGSTs().get(i));
            insertMap.addValue("makingCharges", model.getMakingCharges().get(i));
            insertMap.addValue("shopId", shopId);
            namedTemplate.update(insertQuery, insertMap);
        }

        // Update the stock
        String updateStockQuery = "update jewellery_details set stock = stock - 1\n" +
                "where item_id in (:itemIds) and shop_id = :shopId";
        MapSqlParameterSource stockUpdateMap = new MapSqlParameterSource("itemIds", model.getItemIds());
        stockUpdateMap.addValue("shopId", shopId);
        namedTemplate.update(updateStockQuery, stockUpdateMap);
    }

    public List<BillJewelleriesModel> getBillJewelleryDetail(long id, long shopId) {
        String detailQuery = "select jd.item_type, jd.item_id, bd.sell_price, bd.sell_gst, bd.making_charges from bill_details bd\n" +
                "inner join jewellery_details jd on bd.item_id = jd.item_id\n" +
                "where jd.shop_id = :shopId and bd.bill_id = :billId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        map.addValue("billId", id);
        return namedTemplate.query(detailQuery, map, (rs, rowNum) -> new BillJewelleriesModel(
                rs.getString("item_type"), rs.getDouble("sell_price"),
                rs.getDouble("sell_gst"), rs.getDouble("making_charges"),
                rs.getLong("item_id")
        ));
    }

    public void deleteByBillId(long shopId, long id) {
        String deleteQuery = "delete from bill_details where bill_id = :billId and shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        map.addValue("billId", id);
        namedTemplate.update(deleteQuery, map);
    }
}
