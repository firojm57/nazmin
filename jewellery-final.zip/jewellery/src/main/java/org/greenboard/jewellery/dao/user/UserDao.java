package org.greenboard.jewellery.dao.user;

import org.greenboard.jewellery.dao.BaseDao;
import org.greenboard.jewellery.model.ShopDetailModel;
import org.greenboard.jewellery.model.UserModel;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDao extends BaseDao {

    private String insertUsersQuery = "insert into users(username, password, enabled, first_name, last_name, email, mobile_no, address, created_at, shop_id)" +
            "\n values(:username, :password, 1, :firstname, :lastname, :email, :mobileNo, :address, now(), :shopId)";

    private String insertAuthorityQuery = "insert into authorities(username, authority) values (:username, 'ROLE_MANAGER')";

    public void saveUser(long shopId, UserModel model) {
        MapSqlParameterSource userParamMap = new MapSqlParameterSource();
        userParamMap.addValue("username", model.getUsername());
        userParamMap.addValue("password", model.getPassword());
        userParamMap.addValue("firstname", model.getFirstName());
        userParamMap.addValue("lastname", model.getLastName());
        userParamMap.addValue("email", model.getEmailId());
        userParamMap.addValue("mobileNo", model.getMobileNo());
        userParamMap.addValue("address", model.getUserAddr());
        userParamMap.addValue("shopId", shopId);
        namedTemplate.update(insertUsersQuery, userParamMap);

        MapSqlParameterSource authParamMap = new MapSqlParameterSource();
        authParamMap.addValue("username", model.getUsername());
        namedTemplate.update(insertAuthorityQuery, authParamMap);
    }

    public List<UserModel> getAllUsersByShopId(long shopId) {
        String allUsersQuery = "select u.username, u.enabled, u.first_name, u.last_name, u.email, u.mobile_no, u.address, a.authority\n" +
                "from users u inner join authorities a on u.username = a.username\n" +
                "where shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        return namedTemplate.query(allUsersQuery, map, (rs, rowNum) -> new UserModel(
                rs.getString("username"), "dummy",
                rs.getInt("enabled"), rs.getString("first_name"),
                rs.getString("last_name"), rs.getString("email"),
                rs.getLong("mobile_no"), rs.getString("address"),
                rs.getString("authority")
        ));
    }

    public ShopDetailModel getShopDetailsById(long shopId) {
        String detailsQuery = "select * from shop_details where shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        return namedTemplate.query(detailsQuery, map, (rs, rowNum) -> new ShopDetailModel(
                rs.getLong("shop_id"), rs.getString("shop_name"),
                rs.getString("shop_logo"), rs.getString("shop_address")
        )).get(0);
    }

    public void deleteById(long shopId, String username) {
        String deleteAuthority = "delete from authorities where username = :userName";
        String deleteUser = "delete from users where username = :userName and shop_id = :shopId";
        MapSqlParameterSource mapAuth = new MapSqlParameterSource();
        mapAuth.addValue("userName", username);

        MapSqlParameterSource userMap = new MapSqlParameterSource();
        userMap.addValue("userName", username);
        userMap.addValue("shopId", shopId);
        namedTemplate.update(deleteAuthority, mapAuth);
        namedTemplate.update(deleteUser, userMap);
    }
}
