package org.greenboard.jewellery.controller.misc;

import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.report.ReportDao;
import org.greenboard.jewellery.dao.user.UserDao;
import org.greenboard.jewellery.model.ReportModel;
import org.greenboard.jewellery.model.ShopDetailModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import java.util.List;

@Controller
public class ReportController extends BaseController {

    @Autowired
    private ReportDao reportDao;

    @Autowired
    private UserDao userDao;

    @GetMapping("/reportPage")
    public String reportPage(@SessionAttribute("shopId") Long shopId, Model model) {
        List<ReportModel> reports = reportDao.getReportsByShopId(shopId);
        logger.info("Report got from db: " + reports);
        ShopDetailModel shopDetails = userDao.getShopDetailsById(shopId);
        logger.info("Shop details in reports: " + shopDetails);
        model.addAttribute("reportList", reports);
        model.addAttribute("shopDetails", shopDetails);
        return "reports";
    }
}
