package org.greenboard.jewellery.controller.user;

import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.user.UserDao;
import org.greenboard.jewellery.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import java.util.List;

@Controller
public class UserController extends BaseController {

    @Autowired
    private UserDao userDao;

    @Autowired
    private BCryptPasswordEncoder encoder;

    @GetMapping("/usersPage")
    public String getAllUsers(@SessionAttribute("shopId") Long shopId, Model model) {
        List<UserModel> users = userDao.getAllUsersByShopId(shopId);
        logger.info("User list in getAllUsers: " + users);
        model.addAttribute("usersList", users);
        return "users";
    }

    @GetMapping("/addUser")
    public String addUser(@SessionAttribute("shopId") Long shopId, Model model) {
        model.addAttribute("shopDetails", userDao.getShopDetailsById(shopId));
        return "add-user";
    }

    @PostMapping("/createUser")
    public String createUser(@SessionAttribute("shopId") Long shopId, Model model, UserModel signupModel) {
        logger.info("UserMode for user creation: " + signupModel);
        signupModel.setPassword(encoder.encode(signupModel.getPassword()));
        userDao.saveUser(shopId, signupModel);
        List<UserModel> users = userDao.getAllUsersByShopId(shopId);
        model.addAttribute("usersList", users);
        logger.info("Users fetched after creation: " + users);
        return "users";
    }

    @GetMapping("/cancelAddUser")
    public String cancelAddUser(@SessionAttribute("shopId") Long shopId, Model model) {
        List<UserModel> users = userDao.getAllUsersByShopId(shopId);
        logger.info("User list after cancel: " + users);
        model.addAttribute("usersList", users);
        return "users";
    }

    @GetMapping("/deleteUser")
    public String deleteUser(@SessionAttribute("shopId") Long shopId, @RequestParam String username, Model model) {
        userDao.deleteById(shopId, username);
        List<UserModel> users = userDao.getAllUsersByShopId(shopId);
        logger.info("User list in getAllUsers: " + users);
        model.addAttribute("usersList", users);
        return "users";
    }
}
