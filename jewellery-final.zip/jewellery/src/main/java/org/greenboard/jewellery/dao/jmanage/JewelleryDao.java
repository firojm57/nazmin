package org.greenboard.jewellery.dao.jmanage;

import org.greenboard.jewellery.dao.BaseDao;
import org.greenboard.jewellery.model.JewelleryViewModel;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class JewelleryDao extends BaseDao {

    public void saveJewellery(JewelleryViewModel jmodel, Long shopId) {
        String insertJewelleryQuery = "insert into jewellery_details (item_name, item_type, stock, carat, price, gst, purchase_date, shop_id)\n" +
                "values (:itemName, :itemType, :stock, :carat, :price, :gst, now(), :shopId)";
        MapSqlParameterSource jewelleryMap = new MapSqlParameterSource();
        jewelleryMap.addValue("itemName", jmodel.getItemName());
        jewelleryMap.addValue("itemType", jmodel.getItemType());
        jewelleryMap.addValue("stock", jmodel.getStock());
        jewelleryMap.addValue("carat", jmodel.getCarat());
        jewelleryMap.addValue("price", jmodel.getPrice());
        jewelleryMap.addValue("gst", jmodel.getGst());
        jewelleryMap.addValue("shopId", shopId);
        namedTemplate.update(insertJewelleryQuery, jewelleryMap);
    }

    public List<JewelleryViewModel> getAllJewelleries(long shopId) {
        String getAllJewelleriesQuery = "select * from jewellery_details\n" +
                "where shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        return namedTemplate.query(getAllJewelleriesQuery, map, ((rs, rowNum) -> new JewelleryViewModel(
                rs.getLong("item_id"), rs.getString("item_name"), rs.getString("item_type"),
                rs.getLong("stock"), rs.getInt("carat"),
                rs.getDouble("price"), rs.getDouble("gst"),
                Optional.ofNullable(rs.getTimestamp("purchase_date")).map(Timestamp::toString).orElse("")
        )));
    }

    public JewelleryViewModel getJewelleryById(long itemId, long shopId) {
        String getAllJewelleriesQuery = "select * from jewellery_details where item_id = :itemId and shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("itemId", itemId);
        map.addValue("shopId", shopId);
        List<JewelleryViewModel> list =  namedTemplate.query(getAllJewelleriesQuery, map, ((rs, rowNum) -> new JewelleryViewModel(
                rs.getLong("item_id"), rs.getString("item_name"), rs.getString("item_type"),
                rs.getLong("stock"), rs.getInt("carat"),
                rs.getDouble("price"), rs.getDouble("gst"),
                Optional.ofNullable(rs.getTimestamp("purchase_date")).map(Timestamp::toString).orElse("")
        )));
        return list.get(0);
    }

    public void updateJewelleryById(JewelleryViewModel jmodel, long shopId) {
        String updateQuery = "update jewellery_details set item_name = :itemName, item_type = :itemType, stock = :stock,\n" +
                "carat = :carat, price = :price, gst = :gst\n" +
                "where item_id = :itemId and shop_id = :shopId";
        MapSqlParameterSource jewelleryMap = new MapSqlParameterSource();
        jewelleryMap.addValue("itemName", jmodel.getItemName());
        jewelleryMap.addValue("itemType", jmodel.getItemType());
        jewelleryMap.addValue("stock", jmodel.getStock());
        jewelleryMap.addValue("carat", jmodel.getCarat());
        jewelleryMap.addValue("price", jmodel.getPrice());
        jewelleryMap.addValue("gst", jmodel.getGst());
        jewelleryMap.addValue("itemId", jmodel.getItemId());
        jewelleryMap.addValue("shopId", shopId);
        namedTemplate.update(updateQuery, jewelleryMap);
    }

    public void deleteById(long id, long shopId) {
        String deleteQuery = "delete from jewellery_details where item_id = :itemId and shop_id = :shopId";
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("itemId", id);
        param.addValue("shopId", shopId);
        namedTemplate.update(deleteQuery, param);
    }

    public JewelleryViewModel getJewelleryByNameSearch(String itemName, long shopId) {
        String getAllJewelleriesQuery = "select * from jewellery_details\n" +
                "where shop_id = :shopId and item_name ilike '%'||:itemName||'%'";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("itemName", itemName);
        map.addValue("shopId", shopId);
        List<JewelleryViewModel> list =  namedTemplate.query(getAllJewelleriesQuery, map, ((rs, rowNum) -> new JewelleryViewModel(
                rs.getLong("item_id"), rs.getString("item_name"), rs.getString("item_type"),
                rs.getLong("stock"), rs.getInt("carat"),
                rs.getDouble("price"), rs.getDouble("gst"),
                Optional.ofNullable(rs.getTimestamp("purchase_date")).map(Timestamp::toString).orElse("")
        )));
        return list.get(0);
    }
}
