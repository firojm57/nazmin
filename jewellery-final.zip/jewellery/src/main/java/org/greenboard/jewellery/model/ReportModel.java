package org.greenboard.jewellery.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class ReportModel {
    private String itemType;
    private Long stock;
    private Double buyPrice;
    private Double buyGST;
    private Double sellPrice;
    private Double sellGST;
    private Double makingCharges;
    private Double profitLoss;
}
