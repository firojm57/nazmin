package org.greenboard.jewellery.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class BillingAllRespModel {
    private Long billId;
    private String custName;
    private Long custMobile;
    private String sellDate;
}
