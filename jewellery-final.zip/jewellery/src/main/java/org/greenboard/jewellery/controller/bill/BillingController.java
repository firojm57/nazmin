package org.greenboard.jewellery.controller.bill;

import org.greenboard.jewellery.OutOfStockException;
import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.bill.BillingDao;
import org.greenboard.jewellery.dao.jmanage.JewelleryDao;
import org.greenboard.jewellery.model.BillingModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

@Controller
public class BillingController extends BaseController {

    @Autowired
    private BillingDao billingDao;

    @Autowired
    private JewelleryDao jewelleryDao;

    @GetMapping("/addBill")
    public String addBill(@SessionAttribute("shopId") Long shopId, Model model) {
        // This is for jewellery type
        model.addAttribute("jewelleryList", jewelleryDao.getAllJewelleries(shopId));
        return "new-bill";
    }

    @GetMapping("/viewBill")
    public String viewBill(@SessionAttribute("shopId") Long shopId, @RequestParam Long id,
            @RequestParam String operation, Model model) {
        // This is for jewellery type
        model.addAttribute("billJewelleryDetails", billingDao.getBillJewelleryDetail(id, shopId));
        model.addAttribute("billCustomerDetail", billingDao.getBillCustomerDetail(id, shopId));
        model.addAttribute("operation", operation);
        return "view-bill";
    }

    @GetMapping("/viewBillings")
    public String viewBillings(@SessionAttribute("shopId") Long shopId, Model model) {
        model.addAttribute("billList", billingDao.getAllBills(shopId));
        return "billing";
    }

    @PostMapping("/createNewBill")
    public String createNewBill(@SessionAttribute("shopId") Long shopId, BillingModel bModel, Model model) {
        logger.info("Got the billing model: " + bModel);
        try {
            billingDao.saveBilling(bModel, shopId);
            logger.info("Bill saved successfully");
            model.addAttribute("billList", billingDao.getAllBills(shopId));
        } catch (OutOfStockException ex) {
            model.addAttribute("isStockError", "true");
        }
        return "billing";
    }

    @GetMapping("/cancelNewBill")
    public String cancelNewBill(@SessionAttribute("shopId") Long shopId, Model model) {
        model.addAttribute("billList", billingDao.getAllBills(shopId));
        return "billing";
    }

    @GetMapping("/doDeleteBill")
    public String doDeleteBill(@SessionAttribute("shopId") Long shopId, @RequestParam Long id, Model model) {
        billingDao.deleteByBillId(shopId, id);
        model.addAttribute("billList", billingDao.getAllBills(shopId));
        return "billing";
    }
}
