package org.greenboard.jewellery;

public class OutOfStockException extends Exception {
    public OutOfStockException(String msg) {
        super(msg);
    }
}
