package org.greenboard.jewellery.dao.report;

import org.greenboard.jewellery.dao.BaseDao;
import org.greenboard.jewellery.model.ReportModel;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ReportDao extends BaseDao {

    public List<ReportModel> getReportsByShopId(long shopId) {
        String reportQuery = "select jd.item_type, jd.stock, jd.price as buy_price, jd.gst as buy_gst,\n" +
                "bd.sell_price, bd.sell_gst, bd.making_charges, (jd.price + jd.gst - bd.sell_price - bd.sell_gst - bd.making_charges) as profit_loss\n" +
                "from bill_details bd\n" +
                "inner join jewellery_details jd on bd.item_id = jd.item_id\n" +
                "where bd.shop_id = :shopId";
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("shopId", shopId);
        return namedTemplate.query(reportQuery, map, (rs, rowNum) -> new ReportModel(
                rs.getString("item_type"), rs.getLong("stock"),
                rs.getDouble("buy_price"), rs.getDouble("buy_gst"),
                rs.getDouble("sell_price"), rs.getDouble("sell_gst"),
                rs.getDouble("making_charges"), rs.getDouble("profit_loss")
        ));
    }
}
