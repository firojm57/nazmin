package org.greenboard.jewellery.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SignupDto {
    private String username;
    private String emailId;
    private String password;
    private String firstName;
    private String lastName;
    private long mobileNo;
    private String userAddr;
    private String shopName;
    private String shopAddr;
    private String shopLogo;
}
