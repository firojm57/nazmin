package org.greenboard.jewellery.controller.home;

import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.home.ShopDetailsDao;
import org.greenboard.jewellery.dto.SessionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class HomeController extends BaseController {
    @Autowired
    private ShopDetailsDao shopDetailsDao;

    @GetMapping(value = {"/home", "/"})
    public String goHome(Model model, @AuthenticationPrincipal User user, HttpServletRequest request) {
        SessionDto sessionDto = shopDetailsDao.getUserSessionAttributes(user.getUsername());
        request.getSession().setAttribute("userName", user.getUsername());
        request.getSession().setAttribute("imgSessionFilePath", sessionDto.getLogoImagePath());
        request.getSession().setAttribute("userRole", sessionDto.getUserRole());
        request.getSession().setAttribute("shopId", sessionDto.getShopId());
        return "home";
    }
}
