package org.greenboard.jewellery.dao.home;

import org.greenboard.jewellery.dao.BaseDao;
import org.greenboard.jewellery.dto.SessionDto;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ShopDetailsDao extends BaseDao {
    private final String getLogoPathQuery = "select shop_logo, sd.shop_id, a.authority from shop_details sd\n" +
            "inner join users u on sd.shop_id = u.shop_id\n" +
            "inner join authorities a on a.username = u.username\n" +
            "where u.username = :username";

    public SessionDto getUserSessionAttributes(String username) {
        MapSqlParameterSource logoParamMap = new MapSqlParameterSource();
        logoParamMap.addValue("username", username);
        logger.info("Username received in Dao: "+ username);
        List<SessionDto> shopLogoRsList = namedTemplate.query(getLogoPathQuery, logoParamMap,
                (rs, index) -> new SessionDto(rs.getString("shop_logo"),
                        rs.getString("authority"), rs.getLong("shop_id")));
        logger.info("Shop logo rs: " + shopLogoRsList);
        return shopLogoRsList.get(0);
    }

}
