package org.greenboard.jewellery.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class JewelleryViewModel {
    private Long itemId;
    private String itemName;
    private String itemType;
    private long stock;
    private int carat;
    private double price;
    private double gst;
    private String purchaseDate;
}
