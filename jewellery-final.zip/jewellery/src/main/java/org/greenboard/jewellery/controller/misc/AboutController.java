package org.greenboard.jewellery.controller.misc;

import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.user.UserDao;
import org.greenboard.jewellery.model.ShopDetailModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

@Controller
public class AboutController extends BaseController {

    @Autowired
    private UserDao userDao;

    @GetMapping("/about")
    public String aboutPage(@SessionAttribute("shopId") Long shopId, Model model) {
        ShopDetailModel shopDetails = userDao.getShopDetailsById(shopId);
        logger.info("Shop details in About controller: " + shopDetails);
        model.addAttribute("shopDetails", shopDetails);
        return "about";
    }
}
