package org.greenboard.jewellery.dao.signup;

import org.greenboard.jewellery.dao.BaseDao;
import org.greenboard.jewellery.dto.SignupDto;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SignupDao extends BaseDao {

    private String insertShopDetailsQuery = "insert into shop_details(shop_name, shop_logo, shop_address)"
            + "\n values(:shopName, :shopLogo, :shopAddress)";

    private String insertUsersQuery = "insert into users(username, password, enabled, first_name, last_name, email, mobile_no, address, created_at, shop_id)" +
            "\n values(:username, :password, 1, :firstname, :lastname, :email, :mobileNo, :address, now(), :shopId)";

    private String insertAuthorityQuery = "insert into authorities(username, authority) values (:username, 'ROLE_ADMIN')";

    public void saveSignupUser(SignupDto signupDto) {
        MapSqlParameterSource shopParamMap = new MapSqlParameterSource();
        shopParamMap.addValue("shopName", signupDto.getShopName());
        shopParamMap.addValue("shopLogo", signupDto.getShopLogo());
        shopParamMap.addValue("shopAddress", signupDto.getShopAddr());
        namedTemplate.update(insertShopDetailsQuery, shopParamMap);

        MapSqlParameterSource userParamMap = new MapSqlParameterSource();
        userParamMap.addValue("username", signupDto.getUsername());
        userParamMap.addValue("password", signupDto.getPassword());
        userParamMap.addValue("firstname", signupDto.getFirstName());
        userParamMap.addValue("lastname", signupDto.getLastName());
        userParamMap.addValue("email", signupDto.getEmailId());
        userParamMap.addValue("mobileNo", signupDto.getMobileNo());
        userParamMap.addValue("address", signupDto.getUserAddr());
        userParamMap.addValue("shopId", getShopIdByNameLogo(signupDto.getShopName(), signupDto.getShopLogo()));
        namedTemplate.update(insertUsersQuery, userParamMap);

        MapSqlParameterSource authParamMap = new MapSqlParameterSource();
        authParamMap.addValue("username", signupDto.getUsername());
        namedTemplate.update(insertAuthorityQuery, authParamMap);
    }

    private long getShopIdByNameLogo(String shopName, String shopLogo) {
        MapSqlParameterSource shopIdParam = new MapSqlParameterSource();
        shopIdParam.addValue("shopName", shopName);
        shopIdParam.addValue("shopLogo", shopLogo);

        final String getShopIdQuery = "select shop_id from shop_details where shop_name = :shopName and shop_logo = :shopLogo";
        List<Long> shopIdList = namedTemplate.query(getShopIdQuery, shopIdParam, (rs, index) -> rs.getLong("shop_id"));
        return shopIdList.get(0);
    }
}
