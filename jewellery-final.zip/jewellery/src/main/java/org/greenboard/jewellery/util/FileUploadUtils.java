package org.greenboard.jewellery.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class FileUploadUtils {
    private static final Logger logger = LoggerFactory.getLogger(FileUploadUtils.class);

    public static final String STATIC_IMAGES_LOGO = "/WEB-INF/classes/static/images/logo";

    public static String saveFile(Path uploadPath, String fileName, MultipartFile multipartFile) throws IOException {
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        Path filePath;
        try (InputStream inputStream = multipartFile.getInputStream()) {
            filePath = uploadPath.resolve(fileName);
            logger.info("Path while uploading: " + filePath);
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioe) {
            logger.error("Error while uploading");
            throw new IOException("Could not save image file: " + fileName, ioe);
        }
        return "/jewellery-app/images/logo/" + fileName;
    }
}
