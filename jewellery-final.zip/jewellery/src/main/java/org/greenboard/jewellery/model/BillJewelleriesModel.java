package org.greenboard.jewellery.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class BillJewelleriesModel {
    private String itemType;
    private double sellPrice;
    private double sellGST;
    private double makingCharge;
    private long itemId;
}
