package org.greenboard.jewellery.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class UserModel {
    private String username;
	private String password;
    private Integer enabled;
    private String firstName;
    private String lastName;
    private String emailId;
    private Long mobileNo;
    private String userAddr;
    private String authority;
}
