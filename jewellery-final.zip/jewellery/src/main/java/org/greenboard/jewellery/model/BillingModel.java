package org.greenboard.jewellery.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class BillingModel {
    private List<Long> itemIds;
    private Long billId;
    private String custName;
    private Long custMobile;
    private List<Double> sellPrices;
    private List<Double> sellGSTs;
    private List<Double> makingCharges;
    private String sellDate;
}
