package org.greenboard.jewellery.controller.jmanage;

import org.greenboard.jewellery.controller.BaseController;
import org.greenboard.jewellery.dao.jmanage.JewelleryDao;
import org.greenboard.jewellery.model.JewelleryViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

@Controller
public class JewelleryManageController extends BaseController {

    @Autowired
    private JewelleryDao jewelleryDao;

    @GetMapping("/addJewellery")
    public String addJewellery() {
        return "add-jewellery";
    }

    @PostMapping("/doAddJewellery")
    public String doAddJewellery(@SessionAttribute("shopId") Long shopId, JewelleryViewModel jewelleryModel, Model model) {
        logger.info("Jewellery model received to save: " + jewelleryModel);
        logger.info("Shop id in session: " + shopId);
        jewelleryDao.saveJewellery(jewelleryModel, shopId);
        model.addAttribute("jewelleryList", jewelleryDao.getAllJewelleries(shopId));
        return "jewellery-man";
    }

    @GetMapping("cancelAddJewellery")
    public String cancelAddJewellery(@SessionAttribute("shopId") Long shopId, Model model) {
        model.addAttribute("jewelleryList", jewelleryDao.getAllJewelleries(shopId));
        return "jewellery-man";
    }

    @GetMapping("/man-jewellery")
    public String manageJewellery(@SessionAttribute("shopId") Long shopId, Model model) {
        model.addAttribute("jewelleryList", jewelleryDao.getAllJewelleries(shopId));
        return "jewellery-man";
    }

    @GetMapping("/searchJewellery")
    public String searchJewellery(@SessionAttribute("shopId") Long shopId, @RequestParam("itemName") String itemName, Model model) {
        logger.info("Item id for edit: " + itemName);
        model.addAttribute("jewelleryDetail", jewelleryDao.getJewelleryByNameSearch(itemName, shopId));
        return "edit-jewellery";
    }

    @GetMapping("/editJewellery")
    public String editJewellery(@SessionAttribute("shopId") Long shopId, @RequestParam("id") long id, Model model) {
        logger.info("Item id for edit: " + id);
        logger.info("Shop id in session: " + shopId);
        model.addAttribute("jewelleryDetail", jewelleryDao.getJewelleryById(id, shopId));
        return "edit-jewellery";
    }

    @PostMapping("/doEditJewellery")
    public String doEditJewellery(@SessionAttribute("shopId") Long shopId, JewelleryViewModel jmodel, Model model) {
        jewelleryDao.updateJewelleryById(jmodel, shopId);
        logger.info("Model for edit: " + jmodel);
        model.addAttribute("jewelleryList", jewelleryDao.getAllJewelleries(shopId));
        return "jewellery-man";
    }

    @GetMapping("/deleteJewellery")
    public String deleteJewellery(@SessionAttribute("shopId") Long shopId, @RequestParam("id") long id, Model model) {
        model.addAttribute("jewelleryDetail", jewelleryDao.getJewelleryById(id, shopId));
        return "delete-jewellery";
    }

    @GetMapping("doDeleteJewellery")
    public String doDeleteJewellery(@SessionAttribute("shopId") Long shopId, @RequestParam("id") long id, Model model) {
        logger.info("Id for delete: " + id);
        jewelleryDao.deleteById(id, shopId);
        model.addAttribute("jewelleryList", jewelleryDao.getAllJewelleries(shopId));
        return "jewellery-man";
    }
}
